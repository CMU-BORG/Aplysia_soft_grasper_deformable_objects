README — Dataset Column Definitions
===================================

This file describes the meaning of each column in the dataset used for the noise immunity validation tests on the robot.

Files with a "Control Type" of SNS_MC_Tau0.05 represents the Tau preceptor of the robot set to 0.05 seconds, which allows the dynamics of the SNS to filter noise and results in successful pick-and-place for both rigid and soft graspers. Controller is based on the SNS controller detailed in [1] 

Files with a "Control Type" of SNS_MC_Tau0 represents the Tau preceptor of the robot set to 0 seconds, so the dynamics of the SNS  neurons do not allow filtering of noise which prevents successful pick and place. 

10 mm amplitude artificial noise was added to the position feedback (x,y,z axes) to simulate a noisy environment in the robot experiments

 
The parquet files can be opened and converted to other format in Pandas or other open source software. 

-----------------------------------
INDEXING AND TIMING
-----------------------------------

index  
    Sequential row number for the dataset.

yyyy mm dd hh mm ss timestamp  
    Timestamp broken into year, month, day, hour, minute, second.

milliseconds timestamp  
    Timestamp expressed in milliseconds since the start of the experiment or epoch.

time_delta_s  
    Time elapsed (in seconds) since the previous recorded row.

Modified Timestamp (s)  
    A processed or normalized timestamp used for analysis relative to the start of the SNS (USE_SNS start is equal to time 0).

-----------------------------------
ROBOT POSITION AND MOTION
-----------------------------------

x_mm, y_mm, z_mm  
    Robot end‑effector position in millimeters along the X, Y, and Z axes.

Change In Position (mm)  
    Distance moved since the previous recorded position.

current position 1, current position 2  
    Raw position readings from the rigid grasper linear actuators.

currentDistance_mm  
    Current measured distance between gripper jaws.

commandedPosition_mm  
    Target jaw distance commanded by the controller (rigid and soft).

-----------------------------------
GRIPPER STATE AND PRESSURE
-----------------------------------

P_closure_psi  
    Pressure applied to close the soft grasper, measured in psi.

P_jaw1_psi, P_jaw2_Psi, P_jaw3_psi
    Soft grasper pressure at the elastic jaws.

commanded_radius_mm  
    Desired diameter of the gripper opening (converted from jaw distance).

current closure distance (mm)  
    Actual measured closure distance (diameter) between gripper jaws.

jaw force (N)  
    Real‑time measured force applied by the gripper jaws.

Max Jaw Pressure (psi)  
    Pressure recorded during the grasp attempt at the jaws for the soft grasper.

Max Force (N)  
    Force recorded during the grasp attempt, converted from jaw pressure.

-----------------------------------
GRASPING ACTION FLAGS
-----------------------------------

move_to_pre_grasp  
move_to_grasp  
grasp  
lift_after_grasp  
move_to_pre_release  
move_to_release  
release  
lift_after_release  
    Boolean or binary indicators (0/1) marking which phase of the grasping
    sequence the robot is currently executing in the SNS.

Mode  
    Mode of the system. NORMAL means that the SNS has not started. USE_SNS means that the SNS is controlling the pick-and-	place.

-----------------------------------
EXPERIMENT METADATA
-----------------------------------

ID  
    Unique identifier for this trial.

Master ID  
    Identifier linking multiple rows to a single experiment (grasper + control Type + experimental condition + experiment 	iteration.

Grasper  
    Identifier for the gripper hardware used.

Control Type  
    Type of control strategy. Uses the Modulation control detailed in Li et al. 2024 [1]. Tau set to 0.05 to enable filtering of noise, Tau set to 0 to disable filtering. 


Experimental Condition  
    Condition under which the experiment was run. If feedforward position control (i.e. Open), then this will be 	35, 40 and 45 mm which translate to a change in diameter of 15, 10 and 5 mm, respectively. In threshold force control, this is the scaling factor to produce the threshold, i.e. 12/K where K  = 2.4, 3.0, and 4, which translate to 5N, 4N, and 3N respectively

Experiment Iteration  
    Trial number for repeated experiments under the same condition.


-----------------------------------
FORCE DATA ARRAYS
-----------------------------------

RawForceArray (count)  
    Raw force value measured from load cell for the rigid grasper.

ForceArray (N)  
    Processed force values (in Newtons), for rigid grasper.




------------------------------- References -------------------------------
[1] Y. Li, R. Sukhnandan, H. J. Chiel, V. A. Webster-Wood, and R. D. Quinn, “Modulation and Time-History-Dependent Adaptation Improves the Pick-and-Place Control of a Bioinspired Soft Grasper,” in Biomimetic and Biohybrid Systems: 13th International Conference, Living Machines 2024, Chicago, IL, USA, July 8–11, 2024, Proceedings, Berlin, Heidelberg: Springer-Verlag, Dec. 2024, pp. 351–367. doi: 10.1007/978-3-031-72597-5_24.